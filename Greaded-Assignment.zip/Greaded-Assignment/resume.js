document.addEventListener("DOMContentLoaded", function () {
  const loggedIn = localStorage.getItem("loggedIn");
  if (!loggedIn) {
    window.location.href = "resume.html";
  }

  let applicants; // Array to store the applicant data
  let filteredApplicants; // Array to store the filtered applicants

  // Fetch data from data.json
  fetch('data.json')
    .then(response => response.json())
    .then(data => {
      applicants = data.resume; // Store the fetched data in the applicants array
      filteredApplicants = applicants; // Initialize filteredApplicants with all applicants

      let currentApplicantIndex = 0;

      const applicantDetails = document.getElementById("applicant-details");
      const previousButton = document.getElementById("previous");
      const nextButton = document.getElementById("next");
      const jobFilter = document.getElementById("job-filter");
      const filterButton = document.getElementById("filter-button");
      const errorMessage = document.getElementById("error-message");

      function displayApplicantDetails(index) {
        if (filteredApplicants[index]) {
          const applicant = filteredApplicants[index].basics;
          const skills = filteredApplicants[index].skills;
          const work = filteredApplicants[index].work;
          const internship = filteredApplicants[index].internship;
          const projects = filteredApplicants[index].projects;
          const education = filteredApplicants[index].education;
          const achievements = filteredApplicants[index].achievements;
          const interests = filteredApplicants[index].interests;

          // Display applicant details
          applicantDetails.innerHTML = `
            <h2>${applicant.name}</h2>
            <p>Applied For: ${applicant.AppliedFor}</p>
            <p>Email: ${applicant.email}</p>
            <p>Phone: ${applicant.phone}</p>
            <p>Location: ${applicant.location.city}, ${applicant.location.state}</p>
            <p>LinkedIn Profile: <a href="${applicant.profiles.url}" target="_blank">${applicant.profiles.network}</a></p>
            <h3>Skills</h3>
            <p>Name: ${skills.name}</p>
            <p>Level: ${skills.level}</p>
            <p>Keywords: ${skills.keywords.join(', ')}</p>
            <h3>Work Experience</h3>
            <p>Company Name: ${work["Company Name"]}</p>
            <p>Position: ${work.Position}</p>
            <p>Start Date: ${work["Start Date"]}</p>
            <p>End Date: ${work["End Date"]}</p>
            <p>Summary: ${work.Summary}</p>
            <h3>Internship</h3>
            <p>Company Name: ${internship["Company Name"]}</p>
            <p>Position: ${internship.Position}</p>
            <p>Start Date: ${internship["Start Date"]}</p>
            <p>End Date: ${internship["End Date"]}</p>
            <p>Summary: ${internship.Summary}</p>
            <h3>Projects</h3>
            <p>Name: ${projects.name}</p>
            <p>Description: ${projects.description}</p>
            <h3>Education</h3>
            <p>Institute: ${education.UG.institute}</p>
            <p>Course: ${education.UG.course}</p>
            <p>Start Date: ${education.UG["Start Date"]}</p>
            <p>End Date: ${education.UG["End Date"]}</p>
            <p>CGPA: ${education.UG.cgpa}</p>
            <h3>Achievements</h3>
            <ul>${achievements.Summary.map(achievement => `<li>${achievement}</li>`).join('')}</ul>
            <h3>Interests</h3>
            <p>Hobbies: ${interests.hobbies.join(', ')}</p>
          `;
        }
        updateNavigationButtons(index);
      }

      function updateNavigationButtons(index) {
        previousButton.style.display = index > 0 ? "block" : "none";
        nextButton.style.display = index < filteredApplicants.length - 1 ? "block" : "none";
      }

      displayApplicantDetails(currentApplicantIndex);

      previousButton.addEventListener("click", function () {
        if (currentApplicantIndex > 0) {
          currentApplicantIndex--;
          displayApplicantDetails(currentApplicantIndex);
        }
      });

      nextButton.addEventListener("click", function () {
        if (currentApplicantIndex < filteredApplicants.length - 1) {
          currentApplicantIndex++;
          displayApplicantDetails(currentApplicantIndex);
        }
      });

      filterButton.addEventListener("click", function () {
        const filterValue = jobFilter.value.toLowerCase();
        if (!filterValue) {
          filteredApplicants = applicants; // No filter, show all applicants
        } else {
          filteredApplicants = applicants.filter(applicant => applicant.basics.AppliedFor.toLowerCase() === filterValue);
        }

        if (filteredApplicants.length === 0) {
          errorMessage.textContent = "Invalid search or No applications for this job.";
          applicantDetails.innerHTML = ""; // Clear applicant details
          previousButton.style.display = "none";
          nextButton.style.display = "none";
        } else {
          currentApplicantIndex = 0;
          errorMessage.textContent = "";
          displayApplicantDetails(currentApplicantIndex);
        }
      });
    })
    .catch(error => {
      console.error("Error fetching data: " + error);
    });
});
